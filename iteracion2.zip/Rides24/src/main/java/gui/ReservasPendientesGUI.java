package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import businessLogic.BLFacade;
import domain.*;

public class ReservasPendientesGUI extends JFrame {
    public ReservasPendientesGUI(Driver driver) {
        setTitle("Reservas Pendientes");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        BLFacade facade = MainGUI.getBusinessLogic();
        List<Reserva> reservasPendientes = facade.getReservasPendientes(driver);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        for (Reserva reserva : reservasPendientes) {
            JPanel reservaPanel = new JPanel(new FlowLayout());

            JLabel info = new JLabel("Pasajero: " + reserva.getTraveler().getName() +
                    " | Viaje: " + reserva.getRide().getFrom() + " → " + reserva.getRide().getTo());

            JButton btnAceptar = new JButton("Aceptar");
            JButton btnRechazar = new JButton("Rechazar");

            btnAceptar.addActionListener(e -> {
                reserva.setAceptada(true);
                facade.actualizarReserva(reserva);
                JOptionPane.showMessageDialog(this, "Reserva aceptada.");
                this.dispose();
                new ReservasPendientesGUI(driver).setVisible(true); 
            });

            btnRechazar.addActionListener(e -> {
                facade.eliminarReserva(reserva); 
                JOptionPane.showMessageDialog(this, "Reserva rechazada.");
                this.dispose();
                new ReservasPendientesGUI(driver).setVisible(true);
            });

            reservaPanel.add(info);
            reservaPanel.add(btnAceptar);
            reservaPanel.add(btnRechazar);
            panel.add(reservaPanel);
        }
        getContentPane().setLayout(null);

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBounds(0, 0, 486, 363);
        getContentPane().add(scrollPane);
    }
}
